

;;; carregar (tela DOS)

>lisp -M lispinit.mem


;;; Sair 
(quit)